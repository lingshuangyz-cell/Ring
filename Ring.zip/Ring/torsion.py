from __future__ import annotations

import itertools
import math
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

cv2.setNumThreads(1)
cv2.setRNGSeed(0)

# User settings
INPUT_DIR = Path(r"***")
OUTPUT_DIR = Path(r"***")
REFERENCE_FRAME_INDEX = 0
TRUE_STEP_DEG = 1.0  # Expected angle increment per adjacent pair (degrees)

# Ring-center detection
RED_H1 = (0, 12)
RED_H2 = (168, 179)
GREEN_H = (38, 90)
BLUE_H = (91, 128)
SAT_MIN = 45
VALUE_MIN = 40
CENTER_ROI_HALF_SIZE = 115
RING_RADIUS_MIN_PX = 35
RING_RADIUS_MAX_PX = 85
COARSE_CENTER_INLIER_PX = 8.0
REFINED_CENTER_INLIER_PX = 6.0

# Initial marker refinement
STRICT_AUTO_INITIALIZATION = True
AUTO_GEOMETRIC_CENTER_REFINEMENT = True
AUTO_LOCAL_REFINE_RADIUS_PX = 14
AUTO_OUTLIER_SEARCH_RADIUS_PX = 16
AUTO_MIDPOINT_RESIDUAL_TRIGGER_PX = 3.0
AUTO_OUTLIER_MIN_IMPROVEMENT_PX = 2.0
AUTO_OUTLIER_MAX_PREDICT_DISTANCE_PX = 10.0

# Marker tracking
TEMPLATE_RADIUS_PX = 8
TEMPLATE_SEARCH_RADIUS_PX = 12
TEMPLATE_MIN_CORRELATION = 0.45
def natural_key(path: Path):
    parts = re.split('(\\d+)', path.name.lower())
    return [int(p) if p.isdigit() else p for p in parts]

def list_images(folder: Path) -> List[Path]:
    if not folder.exists():
        raise FileNotFoundError(f'Input folder does not exist: {folder}')
    paths = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in {'.jpg', '.jpeg', '.png', '.bmp', '.tif', '.tiff'}]
    paths.sort(key=natural_key)
    if len(paths) < 2:
        raise RuntimeError(f'At least two images are required. Found {len(paths)} images.')
    return paths

def imread_unicode(path: Path) -> np.ndarray:
    data = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if image is None:
        raise RuntimeError(f'Cannot read image: {path}')
    return image

def wrap_angle_deg(angle: float) -> float:
    return float((angle + 180.0) % 360.0 - 180.0)

def sort_points_top_clockwise(points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(4, 2)
    center = points.mean(axis=0)
    angles = np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0])
    order = np.argsort(angles)
    ordered = points[order]
    start = int(np.argmin(ordered[:, 1]))
    ordered = np.roll(ordered, -start, axis=0)
    area2 = 0.0
    for i in range(4):
        x1, y1 = ordered[i]
        x2, y2 = ordered[(i + 1) % 4]
        area2 += x1 * y2 - x2 * y1
    if area2 < 0:
        ordered = ordered[[0, 3, 2, 1]]
    return ordered.astype(np.float32)

def _convert_ellipse_to_full(ellipse, scale: float):
    (cx, cy), (w, h), angle = ellipse
    return ((cx / scale, cy / scale), (w / scale, h / scale), angle)

def _ellipse_rho_grid(x_grid: np.ndarray, y_grid: np.ndarray, ellipse) -> np.ndarray:
    (cx, cy), (w, h), angle = ellipse
    alpha = np.deg2rad(angle)
    dx = x_grid - cx
    dy = y_grid - cy
    u = np.cos(alpha) * dx + np.sin(alpha) * dy
    v = -np.sin(alpha) * dx + np.cos(alpha) * dy
    return np.sqrt((u / (0.5 * w + 1e-09)) ** 2 + (v / (0.5 * h + 1e-09)) ** 2)

def _quadruplet_geometry_score(selected: Sequence[Tuple[float, float, float]], center: np.ndarray) -> Tuple[float, Optional[np.ndarray]]:
    pts = np.asarray([[p[0], p[1]] for p in selected], dtype=np.float64)
    responses = np.asarray([p[2] for p in selected], dtype=np.float64)
    angles = np.degrees(np.arctan2(pts[:, 1] - center[1], pts[:, 0] - center[0])) % 360.0
    order = np.argsort(angles)
    pts = pts[order]
    responses = responses[order]
    angles = angles[order]
    gaps = np.diff(np.r_[angles, angles[0] + 360.0])
    if float(gaps.min()) < 35.0 or float(gaps.max()) > 145.0:
        return (-1000000000000.0, None)
    angle_penalty = float(np.sum(((gaps - 90.0) / 25.0) ** 2))
    midpoint_a = 0.5 * (pts[0] + pts[2])
    midpoint_b = 0.5 * (pts[1] + pts[3])
    mean_radius = float(np.mean(np.linalg.norm(pts - center, axis=1)))
    midpoint_penalty = float(np.linalg.norm(midpoint_a - midpoint_b) / (mean_radius + 1e-09))
    diag_1 = float(np.linalg.norm(pts[0] - pts[2]))
    diag_2 = float(np.linalg.norm(pts[1] - pts[3]))
    diagonal_penalty = abs(math.log((diag_1 + 1e-09) / (diag_2 + 1e-09)))
    sides = np.asarray([np.linalg.norm(pts[(i + 1) % 4] - pts[i]) for i in range(4)], dtype=np.float64)
    opposite_side_penalty = abs(math.log((sides[0] + 1e-09) / (sides[2] + 1e-09))) + abs(math.log((sides[1] + 1e-09) / (sides[3] + 1e-09)))
    response_score = float(np.mean(responses) / 40.0)
    score = 2.5 * response_score - 1.5 * angle_penalty - 2.0 * midpoint_penalty - 1.0 * diagonal_penalty - 0.5 * opposite_side_penalty
    return (score, pts)

def _refine_peak_weighted(response: np.ndarray, x: int, y: int, radius: int=4) -> np.ndarray:
    h, w = response.shape
    x0 = max(0, x - radius)
    x1 = min(w, x + radius + 1)
    y0 = max(0, y - radius)
    y1 = min(h, y + radius + 1)
    patch = response[y0:y1, x0:x1].astype(np.float64)
    yy, xx = np.indices(patch.shape, dtype=np.float64)
    gx = xx + x0
    gy = yy + y0
    baseline = float(np.percentile(patch, 30.0))
    weights = np.maximum(patch - baseline, 0.0)
    gaussian = np.exp(-((gx - float(x)) ** 2 + (gy - float(y)) ** 2) / (2.0 * 2.2 ** 2))
    weights *= gaussian
    weight_sum = float(weights.sum())
    if weight_sum < 1e-09:
        return np.asarray([float(x), float(y)], dtype=np.float32)
    refined_x = float(np.sum(weights * gx) / weight_sum)
    refined_y = float(np.sum(weights * gy) / weight_sum)
    return np.asarray([refined_x, refined_y], dtype=np.float32)

def _detect_dots_for_ring_candidate(image: np.ndarray, ellipse_full, ring_score: float) -> Tuple[float, Optional[np.ndarray], Dict]:
    h, w = image.shape[:2]
    (cx, cy), (ew, eh), _ = ellipse_full
    half = int(math.ceil(max(ew, eh) * 0.9))
    x0 = max(0, int(math.floor(cx - half)))
    x1 = min(w, int(math.ceil(cx + half + 1)))
    y0 = max(0, int(math.floor(cy - half)))
    y1 = min(h, int(math.ceil(cy + half + 1)))
    roi = image[y0:y1, x0:x1]
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV).astype(np.float32)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    saturation_small = cv2.GaussianBlur(saturation, (0, 0), 1.0)
    value_small = cv2.GaussianBlur(value, (0, 0), 1.0)
    saturation_context = cv2.GaussianBlur(saturation, (0, 0), 5.0)
    value_context = cv2.GaussianBlur(value, (0, 0), 5.0)
    response = 0.9 * (value_small - value_context) + 0.75 * (saturation_context - saturation_small) + 0.22 * saturation_context + 0.05 * value_small
    response = cv2.GaussianBlur(response, (0, 0), 0.8)
    yy, xx = np.indices(response.shape, dtype=np.float32)
    rho = _ellipse_rho_grid(xx + x0, yy + y0, ellipse_full)
    annulus = (rho > 0.58) & (rho < 1.2) & (saturation_context > 42.0)
    annulus_values = response[annulus]
    if annulus_values.size < 50:
        return (-1000000000000.0, None, {})
    local_max = cv2.dilate(response, np.ones((7, 7), dtype=np.uint8))
    threshold = max(18.0, float(np.percentile(annulus_values, 70.0)))
    peak_mask = annulus & (response >= local_max - 1e-06) & (response >= threshold)
    py, px = np.nonzero(peak_mask)
    if len(px) < 4:
        return (-1000000000000.0, None, {})
    peak_values = response[py, px]
    order = np.argsort(peak_values)[::-1]
    distinct: List[Tuple[float, float, float]] = []
    min_distance = max(6.0, 0.05 * max(ew, eh))
    for idx in order:
        local_x = int(px[idx])
        local_y = int(py[idx])
        local_point = _refine_peak_weighted(response, local_x, local_y, radius=4)
        global_x = float(local_point[0] + x0)
        global_y = float(local_point[1] + y0)
        candidate_score = float(peak_values[idx]) + 0.08 * float(saturation_context[local_y, local_x])
        if all(((global_x - qx) ** 2 + (global_y - qy) ** 2 >= min_distance ** 2 for qx, qy, _ in distinct)):
            distinct.append((global_x, global_y, candidate_score))
        if len(distinct) >= 16:
            break
    if len(distinct) < 4:
        return (-1000000000000.0, None, {})
    center = np.asarray([cx, cy], dtype=np.float64)
    best_score = -1000000000000.0
    best_points = None
    for indices in itertools.combinations(range(len(distinct)), 4):
        selected = [distinct[i] for i in indices]
        score, points = _quadruplet_geometry_score(selected, center)
        if points is None:
            continue
        mean_radius = float(np.mean(np.linalg.norm(points - center, axis=1)))
        centroid_penalty = float(np.linalg.norm(points.mean(axis=0) - center) / (mean_radius + 1e-09))
        score -= 0.35 * centroid_penalty
        if score > best_score:
            best_score = score
            best_points = points
    if best_points is None:
        return (-1000000000000.0, None, {})
    refined = sort_points_top_clockwise(np.asarray(best_points, dtype=np.float32))
    total_score = float(best_score + 0.8 * ring_score)
    diagnostics = {'ring_score': float(ring_score), 'quadruplet_score': float(best_score), 'white_response_threshold': float(threshold), 'local_candidate_count': int(len(distinct)), 'ellipse_center_x': float(cx), 'ellipse_center_y': float(cy), 'ellipse_width': float(ew), 'ellipse_height': float(eh)}
    return (total_score, refined, diagnostics)

def detect_four_white_dots_auto(image: np.ndarray) -> Tuple[np.ndarray, Dict]:
    H, W = image.shape[:2]
    scale = min(1.0, 1200.0 / max(H, W))
    small = cv2.resize(image, (int(round(W * scale)), int(round(H * scale))), interpolation=cv2.INTER_AREA)
    hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    raw = ((saturation > 40) & (value > 35)).astype(np.uint8) * 255
    close_size = max(7, int(round(17 * scale)) | 1)
    dilate_size = max(5, int(round(11 * scale)) | 1)
    merged = cv2.morphologyEx(raw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_size, close_size)))
    merged = cv2.dilate(merged, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilate_size, dilate_size)))
    contours, _ = cv2.findContours(merged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        full_w = w / scale
        full_h = h / scale
        if min(full_w, full_h) < 45:
            continue
        if max(full_w, full_h) > 350:
            continue
        if not 0.42 < w / max(h, 1) < 2.4:
            continue
        sub_raw = raw[y:y + h, x:x + w]
        sy, sx = np.nonzero(sub_raw)
        if len(sx) < 120:
            continue
        points = np.column_stack([sx + x, sy + y]).astype(np.float32)
        ellipse_small = cv2.fitEllipse(points.reshape(-1, 1, 2))
        ellipse_full = _convert_ellipse_to_full(ellipse_small, scale)
        (_, _), (ew, eh), _ = ellipse_full
        if min(ew, eh) < 35 or max(ew, eh) > 260:
            continue
        yy, xx = np.indices(raw.shape, dtype=np.float32)
        rho = _ellipse_rho_grid(xx, yy, ellipse_small)
        annulus = (rho > 0.55) & (rho < 1.18)
        inner = rho < 0.42
        if int(annulus.sum()) == 0 or int(inner.sum()) == 0:
            continue
        annulus_density = float(np.mean(raw[annulus] > 0))
        inner_density = float(np.mean(raw[inner] > 0))
        hues = hsv[:, :, 0][annulus & (raw > 0)]
        hue_diversity = float(np.std(hues.astype(np.float32)) / 90.0) if len(hues) >= 20 else 0.0
        ring_score = 3.0 * annulus_density - 1.4 * inner_density + 0.5 * hue_diversity
        score, dots, diagnostics = _detect_dots_for_ring_candidate(image, ellipse_full, ring_score)
        if dots is not None:
            candidates.append((score, dots, diagnostics))
    if not candidates:
        raise RuntimeError('Automatic detection could not find a reliable four-marker set. Check exposure and marker visibility.')
    candidates.sort(key=lambda item: item[0], reverse=True)
    best_score, best_dots, diagnostics = candidates[0]
    diagnostics['total_score'] = float(best_score)
    diagnostics['candidate_count'] = len(candidates)
    return (best_dots.astype(np.float32), diagnostics)

def preprocess_gray(image: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def estimate_similarity(previous_points: np.ndarray, current_points: np.ndarray):
    previous_points = np.asarray(previous_points, dtype=np.float64)
    current_points = np.asarray(current_points, dtype=np.float64)
    center_0 = previous_points.mean(axis=0)
    center_1 = current_points.mean(axis=0)
    a = previous_points - center_0
    b = current_points - center_1
    covariance = a.T @ b
    u, singular_values, vt = np.linalg.svd(covariance)
    rotation = vt.T @ u.T
    if np.linalg.det(rotation) < 0:
        vt[-1, :] *= -1
        rotation = vt.T @ u.T
    scale = float(singular_values.sum() / (np.sum(a * a) + 1e-12))
    translation = center_1 - scale * (rotation @ center_0)
    predicted = (scale * (rotation @ previous_points.T)).T + translation
    residual = float(np.sqrt(np.mean(np.sum((predicted - current_points) ** 2, axis=1))))
    angle = float(np.degrees(np.arctan2(rotation[1, 0], rotation[0, 0])))
    matrix = np.zeros((2, 3), dtype=np.float32)
    matrix[:, :2] = (scale * rotation).astype(np.float32)
    matrix[:, 2] = translation.astype(np.float32)
    return (wrap_angle_deg(angle), scale, residual, matrix)

def transform_points(points: np.ndarray, matrix_2x3: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32)
    homogeneous = np.hstack([points, np.ones((len(points), 1), dtype=np.float32)])
    return (matrix_2x3 @ homogeneous.T).T.astype(np.float32)

def track_points_lk(previous_gray: np.ndarray, current_gray: np.ndarray, previous_points: np.ndarray, window_size: int=19, max_level: int=0, fb_threshold_px: float=0.9):
    p0 = previous_points.reshape(-1, 1, 2).astype(np.float32)
    params = dict(winSize=(window_size, window_size), maxLevel=max_level, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 100, 0.0001), minEigThreshold=1e-06)
    p1, status_forward, error_forward = cv2.calcOpticalFlowPyrLK(previous_gray, current_gray, p0, None, **params)
    p0_back, status_back, _ = cv2.calcOpticalFlowPyrLK(current_gray, previous_gray, p1, None, **params)
    if p1 is None or p0_back is None:
        raise RuntimeError('Optical-flow tracking failed.')
    fb_error = np.linalg.norm(p0_back - p0, axis=2).reshape(-1)
    good = (status_forward.reshape(-1) == 1) & (status_back.reshape(-1) == 1) & np.isfinite(fb_error) & (fb_error <= fb_threshold_px)
    current_points = p1.reshape(-1, 2).astype(np.float32)
    if int(good.sum()) < 3:
        raise RuntimeError(f'Only {int(good.sum())} markers passed the forward-backward check; tracking cannot continue.')
    if int(good.sum()) == 3:
        _, _, _, matrix = estimate_similarity(previous_points[good], current_points[good])
        predicted = transform_points(previous_points, matrix)
        current_points[~good] = predicted[~good]
    return (current_points, good, fb_error, error_forward.reshape(-1))

def _extract_subpixel_patch(gray: np.ndarray, center: np.ndarray, radius: int) -> np.ndarray:
    size = 2 * int(radius) + 1
    return cv2.getRectSubPix(gray, (size, size), (float(center[0]), float(center[1])))

def _subpixel_match_peak(response: np.ndarray, x: int, y: int) -> np.ndarray:
    h, w = response.shape
    dx = 0.0
    dy = 0.0
    if 0 < x < w - 1:
        denominator = float(response[y, x - 1] - 2.0 * response[y, x] + response[y, x + 1])
        if abs(denominator) > 1e-09:
            dx = 0.5 * float(response[y, x - 1] - response[y, x + 1]) / denominator
    if 0 < y < h - 1:
        denominator = float(response[y - 1, x] - 2.0 * response[y, x] + response[y + 1, x])
        if abs(denominator) > 1e-09:
            dy = 0.5 * float(response[y - 1, x] - response[y + 1, x]) / denominator
    return np.asarray([float(x) + float(np.clip(dx, -0.5, 0.5)), float(y) + float(np.clip(dy, -0.5, 0.5))], dtype=np.float32)

def refine_points_with_local_templates(previous_gray: np.ndarray, current_gray: np.ndarray, previous_points: np.ndarray, predicted_points: np.ndarray, template_radius: int=TEMPLATE_RADIUS_PX, search_radius: int=TEMPLATE_SEARCH_RADIUS_PX, minimum_correlation: float=TEMPLATE_MIN_CORRELATION) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    refined = np.asarray(predicted_points, dtype=np.float32).copy()
    correlations = np.full(4, np.nan, dtype=np.float32)
    accepted = np.zeros(4, dtype=bool)
    search_half_size = int(template_radius + search_radius)
    for index, (previous_point, predicted_point) in enumerate(zip(previous_points, predicted_points)):
        template = _extract_subpixel_patch(previous_gray, previous_point, template_radius)
        search_image = _extract_subpixel_patch(current_gray, predicted_point, search_half_size)
        if template.size == 0 or search_image.size == 0 or search_image.shape[0] < template.shape[0] or (search_image.shape[1] < template.shape[1]):
            continue
        response = cv2.matchTemplate(search_image, template, cv2.TM_CCOEFF_NORMED)
        _, maximum, _, maximum_location = cv2.minMaxLoc(response)
        correlations[index] = float(maximum)
        local_peak = _subpixel_match_peak(response, maximum_location[0], maximum_location[1])
        offset = local_peak + float(template_radius) - float(search_half_size)
        candidate = predicted_point + offset
        if np.isfinite(maximum) and maximum >= minimum_correlation and (float(np.linalg.norm(candidate - predicted_point)) <= search_radius + 1.0):
            refined[index] = candidate
            accepted[index] = True
    return (refined, correlations, accepted)

def track_points_template_assisted(previous_gray: np.ndarray, current_gray: np.ndarray, previous_points: np.ndarray) -> Tuple[np.ndarray, Dict]:
    predicted, good, fb_error, lk_error = track_points_lk(previous_gray, current_gray, previous_points)
    refined, correlations, template_accepted = refine_points_with_local_templates(previous_gray, current_gray, previous_points, predicted)
    _, _, residual, matrix = estimate_similarity(previous_points, refined)
    globally_predicted = transform_points(previous_points, matrix)
    point_residuals = np.linalg.norm(refined - globally_predicted, axis=1)
    for bad_index in np.where(point_residuals > 2.5)[0]:
        keep = np.ones(4, dtype=bool)
        keep[bad_index] = False
        try:
            _, _, _, three_point_matrix = estimate_similarity(previous_points[keep], refined[keep])
            predicted_all = transform_points(previous_points, three_point_matrix)
            refined[bad_index] = predicted_all[bad_index]
        except Exception:
            pass
    metrics = {'good_dot_count': int(np.sum(good)), 'forward_backward_mean_px': float(np.mean(fb_error[good])), 'forward_backward_max_px': float(np.max(fb_error[good])), 'lk_error_mean': float(np.mean(lk_error[good])), 'template_correlation_mean': float(np.nanmean(correlations)), 'template_correlation_min': float(np.nanmin(correlations)), 'template_accepted_count': int(np.sum(template_accepted)), 'template_correlations': [float(value) if np.isfinite(value) else float('nan') for value in correlations], 'tracking_similarity_residual_px': float(residual)}
    return (refined.astype(np.float32), metrics)

def build_bidirectional_point_history(grays: Sequence[np.ndarray], reference_index: int, reference_points: np.ndarray) -> Tuple[List[np.ndarray], Dict[Tuple[int, int], Dict]]:
    frame_count = len(grays)
    history: List[Optional[np.ndarray]] = [None] * frame_count
    history[reference_index] = sort_points_top_clockwise(reference_points)
    pair_metrics: Dict[Tuple[int, int], Dict] = {}
    for current_index in range(reference_index - 1, -1, -1):
        source_index = current_index + 1
        tracked, metrics = track_points_template_assisted(grays[source_index], grays[current_index], history[source_index])
        history[current_index] = tracked
        pair_metrics[current_index, source_index] = metrics
    for current_index in range(reference_index + 1, frame_count):
        source_index = current_index - 1
        tracked, metrics = track_points_template_assisted(grays[source_index], grays[current_index], history[source_index])
        history[current_index] = tracked
        pair_metrics[source_index, current_index] = metrics
    if any((points is None for points in history)):
        raise RuntimeError('Some frames are missing marker coordinates after bidirectional tracking.')
    return ([np.asarray(points, dtype=np.float32) for points in history], pair_metrics)

def wrap_deg(angle):
    return (np.asarray(angle, dtype=float) + 180.0) % 360.0 - 180.0

def circular_mean_deg(values_deg, axis=-1):
    rad = np.deg2rad(np.asarray(values_deg, dtype=float))
    sin_mean = np.mean(np.sin(rad), axis=axis)
    cos_mean = np.mean(np.cos(rad), axis=axis)
    return np.rad2deg(np.arctan2(sin_mean, cos_mean))

def sort_points_top_clockwise_local(points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, dtype=np.float32).reshape(4, 2)
    center = points.mean(axis=0)
    angles = np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0])
    order = np.argsort(angles)
    ordered = points[order]
    start = int(np.argmin(ordered[:, 1]))
    ordered = np.roll(ordered, -start, axis=0)
    area2 = 0.0
    for i in range(4):
        x1, y1 = ordered[i]
        x2, y2 = ordered[(i + 1) % 4]
        area2 += x1 * y2 - x2 * y1
    if area2 < 0:
        ordered = ordered[[0, 3, 2, 1]]
    return ordered.astype(np.float32)

def _white_component_candidates_near_target(image: np.ndarray, target_point: np.ndarray, search_radius: int) -> List[Dict]:
    tx, ty = [float(v) for v in np.asarray(target_point).reshape(2)]
    h, w = image.shape[:2]
    radius = int(max(8, search_radius))
    x0 = max(0, int(math.floor(tx - radius)))
    x1 = min(w, int(math.ceil(tx + radius + 1)))
    y0 = max(0, int(math.floor(ty - radius)))
    y1 = min(h, int(math.ceil(ty + radius + 1)))
    roi = image[y0:y1, x0:x1]
    if roi.size == 0:
        return []
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    value = hsv[:, :, 2]
    threshold_pairs = [(70, 160), (80, 160), (90, 150), (100, 140), (110, 130), (120, 130), (130, 120), (140, 120), (150, 120)]
    candidates: List[Dict] = []
    for saturation_max, value_min in threshold_pairs:
        binary = ((saturation <= saturation_max) & (value >= value_min)).astype(np.uint8) * 255
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, np.ones((2, 2), dtype=np.uint8))
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if area < 6.0 or area > 220.0:
                continue
            if len(contour) < 5:
                continue
            x, y, bw, bh = cv2.boundingRect(contour)
            if bw < 3 or bh < 3 or bw > 22 or (bh > 22):
                continue
            bbox_aspect = max(float(bw) / max(float(bh), 1.0), float(bh) / max(float(bw), 1.0))
            if bbox_aspect > 2.8:
                continue
            perimeter = float(cv2.arcLength(contour, True))
            if perimeter <= 1e-09:
                continue
            circularity = float(4.0 * np.pi * area / (perimeter * perimeter))
            if circularity < 0.2:
                continue
            ellipse = cv2.fitEllipse(contour)
            (ecx, ecy), (axis_a, axis_b), _ = ellipse
            if min(axis_a, axis_b) <= 1e-06:
                continue
            ellipse_aspect = float(max(axis_a, axis_b) / min(axis_a, axis_b))
            if ellipse_aspect > 2.6:
                continue
            center = np.asarray([float(ecx + x0), float(ecy + y0)], dtype=np.float32)
            distance = float(np.linalg.norm(center - np.asarray([tx, ty], dtype=np.float32)))
            if distance > float(radius):
                continue
            component_mask = np.zeros(binary.shape, dtype=np.uint8)
            cv2.drawContours(component_mask, [contour], -1, 255, -1)
            mean_saturation = float(cv2.mean(saturation, mask=component_mask)[0])
            mean_value = float(cv2.mean(value, mask=component_mask)[0])
            score = float(distance + 2.0 * (1.0 - circularity) + 0.5 * (ellipse_aspect - 1.0) + 0.01 * mean_saturation - 0.004 * mean_value)
            candidates.append({'point': center, 'score': score, 'distance_to_target': distance, 'area': area, 'circularity': circularity, 'ellipse_aspect': ellipse_aspect, 'mean_saturation': mean_saturation, 'mean_value': mean_value, 'saturation_max': int(saturation_max), 'value_min': int(value_min)})
    candidates.sort(key=lambda item: item['score'])
    unique: List[Dict] = []
    for candidate in candidates:
        if all((float(np.linalg.norm(candidate['point'] - previous['point'])) > 1.25 for previous in unique)):
            unique.append(candidate)
    return unique

def _opposite_midpoint_residual(points: np.ndarray) -> float:
    points = np.asarray(points, dtype=np.float64).reshape(4, 2)
    midpoint_13 = 0.5 * (points[0] + points[2])
    midpoint_24 = 0.5 * (points[1] + points[3])
    return float(np.linalg.norm(midpoint_13 - midpoint_24))

def _predict_one_marker_from_other_three(points: np.ndarray, index: int) -> np.ndarray:
    p = np.asarray(points, dtype=np.float64).reshape(4, 2)
    if index == 0:
        predicted = p[1] + p[3] - p[2]
    elif index == 1:
        predicted = p[0] + p[2] - p[3]
    elif index == 2:
        predicted = p[1] + p[3] - p[0]
    elif index == 3:
        predicted = p[0] + p[2] - p[1]
    else:
        raise IndexError('Marker index must be in the range 0 to 3.')
    return predicted.astype(np.float32)

def refine_auto_detected_white_dots_geometry(image: np.ndarray, coarse_points: np.ndarray) -> Tuple[np.ndarray, Dict]:
    coarse = sort_points_top_clockwise_local(coarse_points)
    if not AUTO_GEOMETRIC_CENTER_REFINEMENT:
        return (coarse, {'enabled': False, 'coarse_points': coarse.tolist(), 'refined_points': coarse.tolist()})
    local_refined = coarse.copy()
    local_details: List[Dict] = []
    for index in range(4):
        candidates = _white_component_candidates_near_target(image, coarse[index], AUTO_LOCAL_REFINE_RADIUS_PX)
        accepted = None
        if candidates:
            best = candidates[0]
            if best['distance_to_target'] <= 6.0:
                local_refined[index] = best['point']
                accepted = best
        local_details.append({'point_index': int(index + 1), 'accepted': bool(accepted is not None), 'candidate': None if accepted is None else {key: value.tolist() if isinstance(value, np.ndarray) else value for key, value in accepted.items()}})
    residual_coarse = _opposite_midpoint_residual(coarse)
    residual_local = _opposite_midpoint_residual(local_refined)
    final_points = local_refined.copy()
    outlier_detail = None
    if residual_local > AUTO_MIDPOINT_RESIDUAL_TRIGGER_PX:
        best_replacement = None
        for index in range(4):
            predicted = _predict_one_marker_from_other_three(local_refined, index)
            candidates = _white_component_candidates_near_target(image, predicted, AUTO_OUTLIER_SEARCH_RADIUS_PX)
            for candidate in candidates[:6]:
                if candidate['distance_to_target'] > AUTO_OUTLIER_MAX_PREDICT_DISTANCE_PX:
                    continue
                trial = local_refined.copy()
                trial[index] = candidate['point']
                new_residual = _opposite_midpoint_residual(trial)
                improvement = residual_local - new_residual
                if improvement < AUTO_OUTLIER_MIN_IMPROVEMENT_PX:
                    continue
                rank_value = float(new_residual + 0.08 * candidate['score'])
                record = {'rank': rank_value, 'index': index, 'predicted': predicted, 'candidate': candidate, 'trial': trial, 'new_residual': float(new_residual), 'improvement': float(improvement)}
                if best_replacement is None or record['rank'] < best_replacement['rank']:
                    best_replacement = record
        if best_replacement is not None:
            final_points = best_replacement['trial'].astype(np.float32)
            candidate = best_replacement['candidate']
            outlier_detail = {'replaced_point_index': int(best_replacement['index'] + 1), 'predicted_point': best_replacement['predicted'].tolist(), 'measured_refined_point': candidate['point'].tolist(), 'distance_to_prediction_px': float(candidate['distance_to_target']), 'circularity': float(candidate['circularity']), 'ellipse_aspect': float(candidate['ellipse_aspect']), 'midpoint_residual_improvement_px': float(best_replacement['improvement'])}
    final_points = sort_points_top_clockwise_local(final_points)
    residual_final = _opposite_midpoint_residual(final_points)
    diagnostics = {'enabled': True, 'coarse_points': coarse.tolist(), 'local_refined_points': local_refined.tolist(), 'refined_points': final_points.tolist(), 'coarse_midpoint_residual_px': float(residual_coarse), 'local_midpoint_residual_px': float(residual_local), 'final_midpoint_residual_px': float(residual_final), 'local_refinement_details': local_details, 'outlier_refinement': outlier_detail}
    return (final_points.astype(np.float32), diagnostics)

def auto_initialize_first_frame(image: np.ndarray):
    try:
        coarse_points, diagnostics = detect_four_white_dots_auto(image)
    except Exception as exc:
        if STRICT_AUTO_INITIALIZATION:
            raise RuntimeError(f'Automatic four-marker detection failed. No manual fallback is used. Original error: {exc}') from exc
        raise
    coarse_points = sort_points_top_clockwise_local(np.asarray(coarse_points, dtype=np.float32))
    refined_points, refinement_diagnostics = refine_auto_detected_white_dots_geometry(image, coarse_points)
    required_keys = ('ellipse_center_x', 'ellipse_center_y', 'ellipse_width', 'ellipse_height')
    missing = [key for key in required_keys if key not in diagnostics]
    if missing:
        raise RuntimeError('Automatic detection is missing ring-ellipse information: ' + ', '.join(missing))
    ring_seed = np.array([float(diagnostics['ellipse_center_x']), float(diagnostics['ellipse_center_y'])], dtype=np.float64)
    diagnostics = dict(diagnostics)
    diagnostics['geometric_refinement'] = refinement_diagnostics
    return (refined_points, ring_seed, diagnostics, coarse_points)

def _fit_color_center(points_xy: np.ndarray):
    points_xy = np.asarray(points_xy, dtype=np.float32)
    if len(points_xy) < 20:
        return None
    try:
        ellipse = cv2.fitEllipse(points_xy.reshape(-1, 1, 2))
    except cv2.error:
        return None
    center = np.asarray(ellipse[0], dtype=np.float64)
    axes = np.asarray(ellipse[1], dtype=np.float64)
    if np.any(axes <= 20.0) or np.any(axes >= 220.0):
        return None
    return center

def estimate_ring_center(image: np.ndarray, search_seed: np.ndarray, debug: bool=False):
    h, w = image.shape[:2]
    cx_seed, cy_seed = map(float, search_seed)
    half = CENTER_ROI_HALF_SIZE
    x0 = max(0, int(round(cx_seed - half)))
    x1 = min(w, int(round(cx_seed + half)))
    y0 = max(0, int(round(cy_seed - half)))
    y1 = min(h, int(round(cy_seed + half)))
    roi = image[y0:y1, x0:x1]
    if roi.size == 0:
        raise RuntimeError('The ring-center search ROI is empty.')
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    H, S, V = cv2.split(hsv)
    masks = {'red': ((H >= RED_H1[0]) & (H <= RED_H1[1]) | (H >= RED_H2[0]) & (H <= RED_H2[1])) & (S >= SAT_MIN) & (V >= VALUE_MIN), 'green': (H >= GREEN_H[0]) & (H <= GREEN_H[1]) & (S >= SAT_MIN) & (V >= VALUE_MIN), 'blue': (H >= BLUE_H[0]) & (H <= BLUE_H[1]) & (S >= SAT_MIN) & (V >= VALUE_MIN)}
    debug_info: Dict = {'roi_box': (x0, y0, x1, y1), 'search_seed': (cx_seed, cy_seed), 'stage1': [], 'stage2': []}
    candidates = []
    for name, mask in masks.items():
        yy, xx = np.nonzero(mask)
        points = np.column_stack([xx + x0, yy + y0]).astype(np.float32)
        if len(points):
            rr = np.sqrt((points[:, 0] - cx_seed) ** 2 + (points[:, 1] - cy_seed) ** 2)
            points = points[(rr >= 32.0) & (rr <= 88.0)]
        center = _fit_color_center(points)
        debug_info['stage1'].append({'name': name, 'count': int(len(points)), 'center': None if center is None else center.tolist()})
        if center is not None:
            candidates.append(center)
    if not candidates:
        raise RuntimeError('No reliable red, green, or blue ring center could be fitted in the current frame.')
    candidates = np.asarray(candidates, dtype=np.float64)
    median_center = np.median(candidates, axis=0)
    distances = np.linalg.norm(candidates - median_center, axis=1)
    good = candidates[distances <= COARSE_CENTER_INLIER_PX]
    if len(good) == 0:
        good = candidates
    coarse_center = np.mean(good, axis=0)
    debug_info['coarse_center'] = coarse_center.tolist()
    refined_candidates = []
    for name, mask in masks.items():
        yy, xx = np.nonzero(mask)
        points = np.column_stack([xx + x0, yy + y0]).astype(np.float32)
        if len(points):
            rr = np.sqrt((points[:, 0] - coarse_center[0]) ** 2 + (points[:, 1] - coarse_center[1]) ** 2)
            points = points[(rr >= RING_RADIUS_MIN_PX) & (rr <= RING_RADIUS_MAX_PX)]
        center = _fit_color_center(points)
        debug_info['stage2'].append({'name': name, 'count': int(len(points)), 'center': None if center is None else center.tolist()})
        if center is not None:
            refined_candidates.append(center)
    if not refined_candidates:
        final_center = coarse_center
    else:
        refined_candidates = np.asarray(refined_candidates, dtype=np.float64)
        med = np.median(refined_candidates, axis=0)
        distances = np.linalg.norm(refined_candidates - med, axis=1)
        good = refined_candidates[distances <= REFINED_CENTER_INLIER_PX]
        if len(good) == 0:
            good = refined_candidates
        final_center = np.mean(good, axis=0)
    debug_info['final_center'] = final_center.tolist()
    if debug:
        return (final_center, debug_info)
    return final_center

def point_polar_angles(point_history: Sequence[np.ndarray], ring_centers: np.ndarray) -> np.ndarray:
    points = np.asarray(point_history, dtype=np.float64)
    centers = np.asarray(ring_centers, dtype=np.float64)
    vectors = points - centers[:, None, :]
    radius = np.linalg.norm(vectors, axis=2)
    if np.any(radius < 1e-06):
        raise RuntimeError('A marker overlaps the ring center, so its radial angle is undefined.')
    return np.rad2deg(np.arctan2(vectors[:, :, 1], vectors[:, :, 0]))

def adjacent_point_rotations(phi: np.ndarray) -> np.ndarray:
    return wrap_deg(phi[1:] - phi[:-1])


def calculate_four_point_result(point_delta_deg: np.ndarray) -> Dict:
    measured = circular_mean_deg(point_delta_deg, axis=1)
    measured = wrap_deg(measured)

    error = measured - TRUE_STEP_DEG
    abs_error = np.abs(error)

    cumulative = np.cumsum(measured)
    true_cumulative = (
        np.arange(1, len(measured) + 1, dtype=float)
        * TRUE_STEP_DEG
    )
    cumulative_error = cumulative - true_cumulative

    return {
        "measured": measured,
        "error": error,
        "abs_error": abs_error,
        "cumulative": cumulative,
        "true_cumulative": true_cumulative,
        "cumulative_error": cumulative_error,
        "MAE": float(np.mean(abs_error)),
        "RMSE": float(np.sqrt(np.mean(error ** 2))),
        "Bias": float(np.mean(error)),
        "Final_Drift": float(cumulative_error[-1]),
        "Final_Abs_Drift": float(abs(cumulative_error[-1])),
    }


def save_excel(path: Path, image_paths: Sequence[Path], result: Dict) -> None:
    workbook = Workbook()
    sheet_name = "FourPoint"
    sheet = workbook.active
    sheet.title = sheet_name

    headers = [
        "N",
        "Subset",
        "Step",
        "From",
        "To",
        "GT_step_deg",
        "Measured_step_deg",
        "Signed_step_error_deg",
        "Abs_step_error_deg",
        "Cumulative_deg",
        "GT_cumulative_deg",
        "Signed_cumulative_error_deg",
        "Abs_cumulative_error_deg",
    ]
    sheet.append(headers)

    for step_index in range(len(result["measured"])):
        sheet.append(
            [
                4,
                "1234",
                step_index + 1,
                image_paths[step_index].name,
                image_paths[step_index + 1].name,
                TRUE_STEP_DEG,
                float(result["measured"][step_index]),
                float(result["error"][step_index]),
                float(result["abs_error"][step_index]),
                float(result["cumulative"][step_index]),
                float(result["true_cumulative"][step_index]),
                float(result["cumulative_error"][step_index]),
                float(abs(result["cumulative_error"][step_index])),
            ]
        )

    summary_row = len(result["measured"]) + 4
    sheet.cell(summary_row, 1, "Metric")
    sheet.cell(summary_row, 2, "Value")
    sheet.cell(summary_row + 1, 1, "Adjacent_MAE_deg")
    sheet.cell(summary_row + 1, 2, result["MAE"])
    sheet.cell(summary_row + 2, 1, "Adjacent_RMSE_deg")
    sheet.cell(summary_row + 2, 2, result["RMSE"])
    sheet.cell(summary_row + 3, 1, "Bias_deg")
    sheet.cell(summary_row + 3, 2, result["Bias"])
    sheet.cell(summary_row + 4, 1, "Final_Drift_deg")
    sheet.cell(summary_row + 4, 2, result["Final_Drift"])
    sheet.cell(summary_row + 5, 1, "Final_Abs_Drift_deg")
    sheet.cell(summary_row + 5, 2, result["Final_Abs_Drift"])

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    for cell in sheet[1]:
        cell.fill = header_fill
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")

    for cell in sheet[summary_row]:
        cell.fill = header_fill
        cell.font = Font(bold=True)

    sheet.freeze_panes = "A2"

    widths = {
        "A": 8, "B": 10, "C": 8, "D": 18, "E": 18,
        "F": 14, "G": 19, "H": 22, "I": 20,
        "J": 18, "K": 20, "L": 27, "M": 25,
    }
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width

    for row in sheet.iter_rows(min_row=2, max_row=summary_row + 5):
        for cell in row:
            if isinstance(cell.value, float):
                cell.number_format = "0.000000"

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    image_paths = list_images(INPUT_DIR)
    images = [imread_unicode(path) for path in image_paths]
    grays = [preprocess_gray(image) for image in images]

    reference_image = images[REFERENCE_FRAME_INDEX]
    auto_points, ring_seed, _, _ = auto_initialize_first_frame(reference_image)

    point_history, _ = build_bidirectional_point_history(
        grays,
        REFERENCE_FRAME_INDEX,
        auto_points,
    )
    point_history = np.asarray(point_history, dtype=np.float64)

    first_center, _ = estimate_ring_center(
        reference_image,
        ring_seed,
        debug=True,
    )

    ring_centers = [first_center]
    previous_center = first_center

    for frame_index in range(1, len(images)):
        center, _ = estimate_ring_center(
            images[frame_index],
            previous_center,
            debug=True,
        )
        ring_centers.append(center)
        previous_center = center

    ring_centers = np.asarray(ring_centers, dtype=np.float64)

    phi = point_polar_angles(point_history, ring_centers)
    point_delta = adjacent_point_rotations(phi)
    result = calculate_four_point_result(point_delta)

    output_file = OUTPUT_DIR / "four_point_torsion.xlsx"
    save_excel(output_file, image_paths, result)

    print(f"Images: {len(image_paths)}")
    print(f"Steps: {len(result['measured'])}")
    print(f"MAE: {result['MAE']:.6f} deg")
    print(f"RMSE: {result['RMSE']:.6f} deg")
    print(f"Output: {output_file}")


if __name__ == "__main__":
    main()
