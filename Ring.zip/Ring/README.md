# Three-Ring Pose and Four-Marker Torsion Estimation

Python implementations for estimating the orientation of a coded eye model from three concentric rings and four white markers.

## Scripts and sample data

- **`pose.py` — Three-ring pose estimation.** Uses the ellipse parameters `(u, v, a, b, alpha)` extracted from **`Ring_1.jpg`**. These parameters are included in the script; the photograph is not required to run the provided pose example. Ring pairs are optimized with a Sampson-distance residual, then combined to estimate 3D position, yaw, and pitch in camera and world coordinates. The output is `outputs/pose_results.xlsx`.
- **`torsion.py` — Four-marker torsion estimation.** Uses **`examples/torsion/Torison_1.jpg`** and **`examples/torsion/Torison_2.jpg`**. The script detects and tracks four white markers, estimates adjacent-frame angular rotation, and exports `outputs/four_point_torsion.xlsx`. Additional image sequences can be placed in the same input folder.

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python pose.py
python torsion.py
```

Both scripts write Excel results to the `outputs/` directory. The pose parameters and sample ellipse data are set within `pose.py`; the torsion input directory and reference angular step (`TRUE_STEP_DEG`) are set near the top of `torsion.py`.

**Torsion reference:** `TRUE_STEP_DEG = 1.0` is the assumed ground-truth increment used to compute error metrics; change it to match the experiment before interpreting MAE or RMSE. With two images, there is one measured angular increment.
