
import numpy as np
import cv2
import pandas as pd
from scipy.optimize import least_squares
import io
from itertools import combinations


# Basic parameter settings
def rotation_from_yaw_pitch(yaw_rad, pitch_rad):
    Ry = np.array([
        [ np.cos(yaw_rad), 0, np.sin(yaw_rad)],
        [ 0,               1, 0             ],
        [-np.sin(yaw_rad), 0, np.cos(yaw_rad)]
    ])

    Rx = np.array([
        [1, 0,                 0                ],
        [0, np.cos(pitch_rad), -np.sin(pitch_rad)],
        [0, np.sin(pitch_rad),  np.cos(pitch_rad)]
    ])

    return Ry @ Rx



def geometric_to_algebraic(xc, yc, a, b, angle_deg):
    theta = np.deg2rad(angle_deg)
    cos_t, sin_t = np.cos(theta), np.sin(theta)
    sin2, cos2 = sin_t ** 2, cos_t ** 2
    a2, b2 = a ** 2, b ** 2

    A = cos2 / a2 + sin2 / b2
    B = 2 * cos_t * sin_t * (1 / a2 - 1 / b2)
    C = sin2 / a2 + cos2 / b2
    D = -2 * A * xc - B * yc
    E = -B * xc - 2 * C * yc
    F = A * xc ** 2 + B * xc * yc + C * yc ** 2 - 1
    return np.array([A, B, C, D, E, F])


def normalize_vector(v, eps=1e-12):
    v = np.asarray(v, dtype=np.float64).reshape(-1)
    n = np.linalg.norm(v)
    if n < eps:
        return v
    return v / n


def apply_extrinsics_correction(n_camera, rvec_world_to_camera):

    R_w2c, _ = cv2.Rodrigues(rvec_world_to_camera)
    R_c2w = R_w2c.T
    n_world = R_c2w @ n_camera
    n_world = normalize_vector(n_world)
    return n_world


def transform_point_camera_to_world(p_camera, rvec_world_to_camera, tvec_world_to_camera):

    R_w2c, _ = cv2.Rodrigues(rvec_world_to_camera)
    R_c2w = R_w2c.T

    p_camera = np.asarray(p_camera).reshape(3)
    tvec_world_to_camera = np.asarray(tvec_world_to_camera).reshape(3)

    p_world = R_c2w @ (p_camera - tvec_world_to_camera)
    return p_world


def compute_rotation_correction(n_ref):

    z_ideal = np.array([0.0, 0.0, 1.0])

    if n_ref[2] < 0:
        n_ref = -n_ref

    v = np.cross(n_ref, z_ideal)
    s = np.linalg.norm(v)
    c = np.dot(n_ref, z_ideal)

    if s < 1e-6:
        return np.eye(3)

    vx = np.array([[0, -v[2], v[1]],
                   [v[2], 0, -v[0]],
                   [-v[1], v[0], 0]])
    R_corr = np.eye(3) + vx + (vx @ vx) * ((1 - c) / (s ** 2))
    return R_corr

# Definition of pitch and yaw angle
def get_euler_angles_world(n_world):

    n_world = normalize_vector(n_world)

    if n_world[2] < 0:
        n_world = -n_world

    yaw_A = np.rad2deg(np.arctan2(-n_world[0], n_world[2]))
    pitch_A = np.rad2deg(np.arctan2(n_world[1], np.sqrt(n_world[0] ** 2 + n_world[2] ** 2)))

    return yaw_A, pitch_A


def joint_sampson_error_rings(params, coeffs_list, radii_list, offsets_list, camera_matrix):
    r_vec = params[:3]
    t_vec = params[3:].reshape(3, 1)

    theta = np.linalg.norm(r_vec)
    if theta < 1e-10:
        R = np.eye(3)
    else:
        k = r_vec / theta
        K_cross = np.array([[0, -k[2], k[1]],
                            [k[2], 0, -k[0]],
                            [-k[1], k[0], 0]])
        R = np.eye(3) + np.sin(theta) * K_cross + (1 - np.cos(theta)) * (K_cross @ K_cross)

    residuals = []
    fx, fy, cx, cy = camera_matrix[0, 0], camera_matrix[1, 1], camera_matrix[0, 2], camera_matrix[1, 2]

    sample_theta = np.linspace(0, 2 * np.pi, 60)
    cos_t, sin_t = np.cos(sample_theta), np.sin(sample_theta)

    for i in range(len(coeffs_list)):
        local_pts = np.vstack([
            radii_list[i] * cos_t,
            radii_list[i] * sin_t,
            np.full_like(sample_theta, offsets_list[i])
        ])

        cam_pts = R @ local_pts + t_vec
        Z = cam_pts[2, :]
        Z_safe = np.maximum(Z, 10.0)

        u = (cam_pts[0, :] * fx / Z_safe) + cx
        v = (cam_pts[1, :] * fy / Z_safe) + cy

        A, B, C, D, E, F = coeffs_list[i]
        V = A * u ** 2 + B * u * v + C * v ** 2 + D * u + E * v + F
        dVdu = 2 * A * u + B * v + D
        dVdv = B * u + 2 * C * v + E
        sampson_dist = V / (np.sqrt(dVdu ** 2 + dVdv ** 2) + 1e-8)
        sampson_dist[Z < 10.0] = 1e5
        residuals.append(sampson_dist)

    return np.concatenate(residuals)


def solve_pose_with_extrinsics(rows_data, real_radii, z_offsets, camera_matrix,
                               rvec_extrinsic, tvec_extrinsic):
    coeffs_list = [geometric_to_algebraic(d['u'], d['v'], d['a'], d['b'], d['alpha']) for d in rows_data]

    d_out = rows_data[-1]
    Z_est = ((camera_matrix[0, 0] + camera_matrix[1, 1]) / 2) * (2 * real_radii[-1]) / (d_out['a'] * 2)
    X_est = (d_out['u'] - camera_matrix[0, 2]) * Z_est / camera_matrix[0, 0]
    Y_est = (d_out['v'] - camera_matrix[1, 2]) * Z_est / camera_matrix[1, 1]

    best_cost = float('inf')
    best_sol = None

    for y in np.radians([-30, 0, 30]):
        for p in np.radians([-20, 0, 20]):
            Ry = np.array([[np.cos(y), 0, np.sin(y)],
                           [0, 1, 0],
                           [-np.sin(y), 0, np.cos(y)]])
            Rx = np.array([[1, 0, 0],
                           [0, np.cos(p), -np.sin(p)],
                           [0, np.sin(p), np.cos(p)]])
            r_temp, _ = cv2.Rodrigues(Ry @ Rx)
            guess = np.concatenate([r_temp.flatten(), [X_est, Y_est, Z_est]])

            try:
                res = least_squares(
                    joint_sampson_error_rings,
                    guess,
                    args=(coeffs_list, real_radii, z_offsets, camera_matrix),
                    max_nfev=100
                )
                if res.cost < best_cost:
                    best_cost, best_sol = res.cost, res.x
            except Exception:
                continue

    if best_sol is None:
        return None, None, None, None

    final_res = least_squares(
        joint_sampson_error_rings,
        best_sol,
        args=(coeffs_list, real_radii, z_offsets, camera_matrix),
        method='lm',
        max_nfev=1000
    )

    t_cam = final_res.x[3:]
    r_cam = final_res.x[:3]

    R_cam, _ = cv2.Rodrigues(r_cam)
    n_cam = R_cam @ np.array([0, 0, 1])

    # Direction vector
    n_world = apply_extrinsics_correction(n_cam, rvec_extrinsic)

    # point coordinates
    t_world = transform_point_camera_to_world(t_cam, rvec_extrinsic, tvec_extrinsic)

    return t_cam, t_world, n_cam, n_world



# Circle pairing and solution
def solve_pose_pairwise_and_average(rows, real_radii, z_offsets, camera_matrix,
                                    rvec_extrinsic, tvec_extrinsic):

    pair_results = []

    for idx_pair in combinations(range(len(rows)), 2):
        i, j = idx_pair
        rows_pair = [rows[i], rows[j]]
        real_radii_pair = [real_radii[i], real_radii[j]]
        z_offsets_pair = [z_offsets[i], z_offsets[j]]

        t_cam, t_world, n_cam, n_world = solve_pose_with_extrinsics(
            rows_pair,
            real_radii_pair,
            z_offsets_pair,
            camera_matrix,
            rvec_extrinsic,
            tvec_extrinsic
        )

        if t_cam is None:
            continue

        cam_yaw, cam_pitch = get_euler_angles_world(n_cam)

        raw_yaw, raw_pitch = get_euler_angles_world(n_world)

        pair_results.append({
            'pair_name': f"{i + 1}{j + 1}",
            'ring_no_1': rows[i]['No.'],
            'ring_no_2': rows[j]['No.'],

            't_cam': np.asarray(t_cam, dtype=np.float64),
            't_world': np.asarray(t_world, dtype=np.float64),

            'n_cam': normalize_vector(n_cam),
            'n_world_raw': normalize_vector(n_world),

            'cam_yaw': cam_yaw,
            'cam_pitch': cam_pitch,

            'raw_yaw': raw_yaw,
            'raw_pitch': raw_pitch
        })

    if len(pair_results) == 0:
        return None, None

    avg_t_cam = np.mean([p['t_cam'] for p in pair_results], axis=0)
    avg_t_world = np.mean([p['t_world'] for p in pair_results], axis=0)

    avg_n_cam = normalize_vector(np.mean([p['n_cam'] for p in pair_results], axis=0))
    avg_n_world_raw = normalize_vector(np.mean([p['n_world_raw'] for p in pair_results], axis=0))

    avg_cam_yaw, avg_cam_pitch = get_euler_angles_world(avg_n_cam)

    avg_raw_yaw, avg_raw_pitch = get_euler_angles_world(avg_n_world_raw)

    avg_result = {
        't_cam': avg_t_cam,
        't_world': avg_t_world,
        'n_cam': avg_n_cam,
        'n_world_raw': avg_n_world_raw,

        'cam_yaw': avg_cam_yaw,
        'cam_pitch': avg_cam_pitch,

        'raw_yaw': avg_raw_yaw,
        'raw_pitch': avg_raw_pitch
    }

    return pair_results, avg_result



# Ring parameter (Pixel coordinates, major and minor axes, tilt angle)
csv_data = """Ring_ID,No.,u,v,a,b,alpha
1,1,1621.11,850.58,90.87,76.62,121.32
1,2,1618.02,849.44,104.7,88.64,120.74
1,3,1613.7,846.9,118.87,101.15,121.59
"""

# Camera Matrix
camera_matrix = np.array([
    [1680.331, 0, 1480.621],
    [0, 1680.745, 865.3798],
    [0, 0, 1]
])


# Rotation vector and translation vector
rvec_extrinsic = np.array([0.0320508843266944,0.0600818714196269,-0.00486993729147095], dtype=np.float64)
tvec_extrinsic = np.array([22.7036177855301,-2.06053375178563,65.5242081893635], dtype=np.float64)

# Circular radius and distance
REAL_RADII = [2.92, 3.42, 3.92]
Z_OFFSETS = [0, 0.31, 0.62]


df = pd.read_csv(io.StringIO(csv_data))
groups = df.groupby('Ring_ID')



raw_results_dict = {}

for rid, g in groups:
    if len(g) != 3:
        continue

    rows = g.sort_values('a').to_dict('records')

    pair_results, avg_result = solve_pose_pairwise_and_average(
        rows,
        REAL_RADII,
        Z_OFFSETS,
        camera_matrix,
        rvec_extrinsic,
        tvec_extrinsic
    )

    if pair_results is not None:
        raw_results_dict[rid] = {
            'pair_results': pair_results,
            'avg_result': avg_result
        }

REF_RING_ID = 5
R_correction = np.eye(3)

print("=" * 120)
if REF_RING_ID in raw_results_dict:
    ref_n_world = raw_results_dict[REF_RING_ID]['avg_result']['n_world_raw']
    R_correction = compute_rotation_correction(ref_n_world)
    print(f"✅ Extract Ring {REF_RING_ID} Zero position error elimination calibration using the 'pairwise average normal' method...")
else:
    print(f"⚠️ No benchmark found Ring_ID={REF_RING_ID}，Skip benchmark calibration.")
print("=" * 120)


final_results = []


print(
    f"{'ID':<4} | {'Type':<8} | {'Cam_Yaw':<10} {'Cam_Pitch':<10} | {'Raw_W_Yaw':<10} {'Raw_W_Pitch':<10} | {'Corr_W_Yaw':<10} {'Corr_W_Pitch':<10}")
print("-" * 150)

for rid, data in raw_results_dict.items():

    for pair_data in data['pair_results']:
        n_cam = pair_data['n_cam']
        n_world_raw = pair_data['n_world_raw']
        t_cam = pair_data['t_cam']
        t_world = pair_data['t_world']

        cam_yaw, cam_pitch = pair_data['cam_yaw'], pair_data['cam_pitch']
        raw_yaw, raw_pitch = pair_data['raw_yaw'], pair_data['raw_pitch']

        n_world_corrected = normalize_vector(R_correction @ n_world_raw)
        corr_yaw, corr_pitch = get_euler_angles_world(n_world_corrected)

        print(
            f"{rid:<4} | {'Pair-' + pair_data['pair_name']:<8} | {cam_yaw:<10.2f} {cam_pitch:<10.2f} | {raw_yaw:<10.2f} {raw_pitch:<10.2f} | {corr_yaw:<10.2f} {corr_pitch:<10.2f}")

        final_results.append({
            'Ring_ID': rid,
            'Result_Type': f"Pair_{pair_data['pair_name']}",

            'Pair_Ring_No_1': pair_data['ring_no_1'],
            'Pair_Ring_No_2': pair_data['ring_no_2'],

            'Trans_X_cam': t_cam[0],
            'Trans_Y_cam': t_cam[1],
            'Trans_Z_cam': t_cam[2],

            'n_cam_x': n_cam[0],
            'n_cam_y': n_cam[1],
            'n_cam_z': n_cam[2],

            'Cam_Yaw': cam_yaw,
            'Cam_Pitch': cam_pitch,

            'Trans_X_world': t_world[0],
            'Trans_Y_world': t_world[1],
            'Trans_Z_world': t_world[2],

            'n_world_raw_x': n_world_raw[0],
            'n_world_raw_y': n_world_raw[1],
            'n_world_raw_z': n_world_raw[2],

            'Raw_World_Yaw': raw_yaw,
            'Raw_World_Pitch': raw_pitch,

            'n_world_corr_x': n_world_corrected[0],
            'n_world_corr_y': n_world_corrected[1],
            'n_world_corr_z': n_world_corrected[2],

            'Corrected_World_Yaw': corr_yaw,
            'Corrected_World_Pitch': corr_pitch,
        })


    avg_data = data['avg_result']
    n_cam_avg = avg_data['n_cam']
    n_world_raw_avg = avg_data['n_world_raw']
    t_cam_avg = avg_data['t_cam']
    t_world_avg = avg_data['t_world']

    cam_yaw_avg, cam_pitch_avg = avg_data['cam_yaw'], avg_data['cam_pitch']
    raw_yaw_avg, raw_pitch_avg = avg_data['raw_yaw'], avg_data['raw_pitch']

    n_world_corrected_avg = normalize_vector(R_correction @ n_world_raw_avg)
    corr_yaw_avg, corr_pitch_avg = get_euler_angles_world(n_world_corrected_avg)


    print(
        f"{rid:<4} | {'Average':<8} | {cam_yaw_avg:<10.2f} {cam_pitch_avg:<10.2f} | {raw_yaw_avg:<10.2f} {raw_pitch_avg:<10.2f} | {corr_yaw_avg:<10.2f} {corr_pitch_avg:<10.2f}")

    final_results.append({
        'Ring_ID': rid,
        'Result_Type': "Average",

        'Pair_Ring_No_1': np.nan,
        'Pair_Ring_No_2': np.nan,

        'Trans_X_cam': t_cam_avg[0],
        'Trans_Y_cam': t_cam_avg[1],
        'Trans_Z_cam': t_cam_avg[2],

        'n_cam_x': n_cam_avg[0],
        'n_cam_y': n_cam_avg[1],
        'n_cam_z': n_cam_avg[2],

        'Cam_Yaw': cam_yaw_avg,
        'Cam_Pitch': cam_pitch_avg,

        'Trans_X_world': t_world_avg[0],
        'Trans_Y_world': t_world_avg[1],
        'Trans_Z_world': t_world_avg[2],

        'n_world_raw_x': n_world_raw_avg[0],
        'n_world_raw_y': n_world_raw_avg[1],
        'n_world_raw_z': n_world_raw_avg[2],

        'Raw_World_Yaw': raw_yaw_avg,
        'Raw_World_Pitch': raw_pitch_avg,

        'n_world_corr_x': n_world_corrected_avg[0],
        'n_world_corr_y': n_world_corrected_avg[1],
        'n_world_corr_z': n_world_corrected_avg[2],

        'Corrected_World_Yaw': corr_yaw_avg,
        'Corrected_World_Pitch': corr_pitch_avg,
    })



output_file = "TEST.xlsx"


df_out = pd.DataFrame(final_results)

df_out = df_out.rename(columns={
    'Raw_Yaw': 'Raw_World_Yaw',
    'Raw_Pitch': 'Raw_World_Pitch',
    'World_Yaw': 'Corrected_World_Yaw',
    'World_Pitch': 'Corrected_World_Pitch'
})



df_R = pd.DataFrame(
    R_correction,
    index=['Row1', 'Row2', 'Row3'],
    columns=['Col1', 'Col2', 'Col3']
)



if REF_RING_ID in raw_results_dict:
    ref_n_world = raw_results_dict[REF_RING_ID]['avg_result']['n_world_raw']

    df_ref = pd.DataFrame({
        'Reference_Ring_ID': [REF_RING_ID],
        'Ref_nx': [ref_n_world[0]],
        'Ref_ny': [ref_n_world[1]],
        'Ref_nz': [ref_n_world[2]]
    })
else:
    df_ref = pd.DataFrame()



with pd.ExcelWriter(output_file, engine='openpyxl') as writer:

    df_out.to_excel(writer,
                    sheet_name='Results',
                    index=False)

    df_R.to_excel(writer,
                  sheet_name='Zero_Correction_Matrix')

    df_ref.to_excel(writer,
                    sheet_name='Reference_Normal',
                    index=False)

print("=" * 150)
print(f"✅ file: {output_file}")

